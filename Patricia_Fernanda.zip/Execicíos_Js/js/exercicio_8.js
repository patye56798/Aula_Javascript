function adi(){
	let n01 = document.getElementById("n_1");
	console.log(n01.value);
	let n02 = document.getElementById("n_2");
	console.log(n02.value);
	
	let adi = parseInt(n01.value) + parseInt( n02.value);
	let resultado = document.getElementsByTagName("p");
	resultado [0].innerHTML = adi;
}                  
		