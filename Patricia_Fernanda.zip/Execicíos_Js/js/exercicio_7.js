function converter(){
	let palavra = document.getElementById('texto').value;
	let resultado = document.getElementsByTagName("p");
	resultado[0].innerHTML = palavra.toUpperCase();
}