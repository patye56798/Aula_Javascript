let aviso = "Tenha um Bom Dia! :)";
alert(aviso);

let resultado = document.write("A mensagem do dia é: " + aviso);