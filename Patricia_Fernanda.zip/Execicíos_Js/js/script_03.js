let num1 = "";
let resultado = "";
let num2 = "";
let operador = "";
function nume(numero){
	if (operador === "") {
		num1 += numero;
		document.getElementById("numb1").innerHTML = num1;
	} else {
		num2 += numero;
		document.getElementById("numb2").innerHTML = num2;
	}
}
function sin(op){
	operador = op;
	document.getElementById("simb").innerHTML = operador;
}
function limpa(){
	num1 = "";
	operador = "";
	num2 = "";
	document.getElementById("numb1").innerHTML = "";
	document.getElementById("simb").innerHTML = "...";
	document.getElementById("numb2").innerHTML = "";
}
function resul(){
	switch (operador){
	  case "/":
		resultado = num1 / num2;
		break;
	  case "x":
		resultado = num1 * num2;
		break;
	  case "-":
		resultado = num1 - num2;
		break;
	  case "+":
		resultado = parseInt(num1) + parseInt(num2);
		break;
	  default:
		resultado = "";
	}
	let q = document.getElementsByClassName("resul");
	q[0].innerHTML = resultado;
}
