let v = 0;
function n(){
    v++;
    v + v;
    let g = document.getElementsByTagName("h1");
	g[0].innerHTML = v;
}