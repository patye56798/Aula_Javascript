function cliqueaqui(){
    let aviso ="opss ocorreu um erro no servidor :(" ; 
    alert (aviso);
}